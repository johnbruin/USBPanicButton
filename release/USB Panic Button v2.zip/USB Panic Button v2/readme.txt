USB Panic Button.exe v2.0


With this new software your useless USB Panic Button will not be useless anymore!

When you start this program it will minimize itself in the system tray and it will notify if your
USB Panic Button is connected or not.

By default When you click the USB Panic Button the screen will shake like an earthquake.
You can change the USB Panic Button behaviour in the settings screen by double clicking the tray icon 
or clicking the right mouse button on the tray icon and select "Settings".

I have included some images, sounds and commands for you to play with in this .zip file.

Ofcourse you can select any picture, sound or command you want. You can even type your own commands.

For example:
	Type "taskmgr.exe" to show up the taskmanager when you hit the button


There is also a feature to control the next slide in Microsoft PowerPoint.

Have fun!

John Bruin 
http://www.johnbruin.net


Release history:
2017-07-16: v2.0 Works in Windows 10
2008-11-30: v1.1 Bugfix: Set picture as topmost window
2008-11-29: v1.0 Initial release
